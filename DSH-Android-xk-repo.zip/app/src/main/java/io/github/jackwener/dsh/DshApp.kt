package io.github.jackwener.dsh

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import io.github.jackwener.dsh.core.capability.AgentScreen
import io.github.jackwener.dsh.core.data.SettingsRepository
import io.github.jackwener.dsh.core.platform.AppLanguage
import io.github.jackwener.dsh.core.platform.Notifications
import io.github.jackwener.dsh.core.trigger.TriggerEvents
import io.github.jackwener.dsh.core.trigger.TriggerHub
import io.github.jackwener.dsh.service.FloatingBallService
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class DshApp : Application() {
    @Inject lateinit var triggers: dagger.Lazy<TriggerHub>
    @Inject lateinit var settings: dagger.Lazy<SettingsRepository>
    @Inject lateinit var secrets: dagger.Lazy<io.github.jackwener.dsh.core.data.SecretStore>
    @Inject lateinit var agentScreen: dagger.Lazy<AgentScreen>
    @Inject lateinit var updater: dagger.Lazy<io.github.jackwener.dsh.core.update.AppUpdater>
    @Inject lateinit var engine: dagger.Lazy<io.github.jackwener.dsh.core.engine.EngineManager>
    @Inject lateinit var a11yKeeper: dagger.Lazy<io.github.jackwener.dsh.core.platform.AccessibilityKeeper>

    override fun onCreate() {
        super.onCreate()
        // Every process (the :engine one posts its notification too): the in-app language choice.
        AppLanguage.applyToProcess(this)
        if (!isMainProcess()) return
        Notifications.createChannels(this)
        importDebugKey()
        TriggerEvents.init(this)
        // Known update, post-install cleanup, the daily 自动检查更新 (network work runs in the background).
        runCatching { updater.get().start() }.onFailure { android.util.Log.e("DshApp", "updater start failed", it) }
        // Startup work must never crash the process (a bad stored rule used to kill every app start).
        val guard = CoroutineExceptionHandler { _, e -> android.util.Log.e("DshApp", "startup task failed", e) }
        val startup = CoroutineScope(SupervisorJob() + Dispatchers.Default + guard)
        // 无障碍保活: 30 分钟兜底检查 + DSH 自己的通知（进程重启时引擎会发）触发的即时检查。
        runCatching { a11yKeeper.get().start(startup) }.onFailure { android.util.Log.e("DshApp", "a11y keeper start failed", it) }
        startup.launch {
            // Import :engine crash records (ApplicationExitInfo / tombstones) from earlier runs.
            runCatching { io.github.jackwener.dsh.core.engine.EngineDiagnostics.collectExitInfo(this@DshApp) }
            runCatching { triggers.get().sync() }.onFailure { android.util.Log.e("DshApp", "automation sync failed", it) }
            if (settings.get().current().floatingBall) runCatching { FloatingBallService.setEnabled(this@DshApp, true) }
            runCatching { agentScreen.get().restoreLeftoverMutes() }
            // 引擎常驻 (#52): every start of :main, including the one boot / an app update / a re-created engine service causes.
            runCatching { engine.get().keepAlive() }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // Android 10–12: a configuration change resets the process locale to the system's.
        AppLanguage.applyToProcess(this)
    }

    /** Debug builds only: device tests provision the key with `run-as <pkg> sh -c 'cat > files/debug.key'`. */
    private fun importDebugKey() {
        if (!BuildConfig.DEBUG) return
        val f = java.io.File(filesDir, "debug.key")
        if (!f.exists()) return
        f.readText().trim().takeIf { it.isNotEmpty() }?.let { secrets.get().write(it) }
        f.delete()
    }

    private fun isMainProcess() = getProcessName() == packageName
}
