package io.github.jackwener.dsh.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import io.github.jackwener.dsh.core.platform.AccessibilityKeeper
import io.github.jackwener.dsh.core.trigger.TriggerEvents
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Notification reading (whitelisted apps) + notification triggers + media session access. */
class DshNotificationListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // 无障碍保活: our own notifications (the engine posts one whenever the process comes back)
        // are a cheap restart signal, so the accessibility binding is checked right away.
        if (sbn.packageName == packageName) {
            AccessibilityKeeper.instance?.onDshNotification(scope)
            return
        }
        val extras = sbn.notification.extras
        TriggerEvents.notificationPosted(
            sbn.packageName,
            extras.getCharSequence("android.title")?.toString() ?: "",
            (extras.getCharSequence("android.bigText") ?: extras.getCharSequence("android.text"))?.toString() ?: "",
        )
    }

    companion object {
        @Volatile var instance: DshNotificationListener? = null
            private set
    }
}
